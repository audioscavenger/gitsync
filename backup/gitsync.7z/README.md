# gitsync

single MSDOS batch to upload and versioning local backups of your project, with fallbacks and fast tracks